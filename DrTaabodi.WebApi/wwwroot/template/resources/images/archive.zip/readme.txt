Iconset: Logos and Brands (https://www.iconfinder.com/iconsets/logos-and-brands)
Author: Flatart (https://www.iconfinder.com/Flatart)
License: Free for commercial use (Include link to authors website) ()
Download date: 2021-11-29